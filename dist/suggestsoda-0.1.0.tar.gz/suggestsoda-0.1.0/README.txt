suggestsoda

This package provides recommendations on which brand of soda to purchase.

pip install suggestsoda

usage:
  import suggestsoda as soda
  soda.recommend()
  soda.avoid()