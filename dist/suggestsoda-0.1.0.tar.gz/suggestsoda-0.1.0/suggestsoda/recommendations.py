def recommend():
	"""Prints a soda recommendation."""
	print("Drink Coca-Cola.")

def avoid():
	"""Prints a soda to avoid."""
	print("Avoid Pepsi.")
